#import <Flutter/Flutter.h>

@interface AlarmPlugin : NSObject<FlutterPlugin>
@end
