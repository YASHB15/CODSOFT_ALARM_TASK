import 'package:flutter/material.dart';

class ColorStatusImageModel {
  final Color colorStatus ;
  final String images ;
  ColorStatusImageModel({required this.colorStatus, required this.images});
}
