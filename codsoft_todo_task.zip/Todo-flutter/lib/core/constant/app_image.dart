class AppImages {
  static String imageRoute = 'assets/images' ;
  static String bgImage = '$imageRoute/bg_.png' ; 
  static String bgDrawer = '$imageRoute/bg_drawar.png' ; 
  static String appBarIcon = '$imageRoute/app_bar_icon.png' ; 
  static String shop = '$imageRoute/shop.png' ; 
  static String health = '$imageRoute/health.png' ; 
  static String location = '$imageRoute/location.png' ; 
  static String other = '$imageRoute/other.png' ; 
  static String sport = '$imageRoute/sport.png' ; 
  static String  main = '$imageRoute/c.png' ; 
  static String  logo = '$imageRoute/logo.png' ; 
}