class AppRoute {
  static String done = '/done' ;
  static String todo = '/todo' ; 
  
}