class AppStrings {
  static String newTask = "NEW TASK" ;
  static String icon = "Icon" ;
  static String name = "Name" ;
  static String description = "Description" ;
  static String data = "Data" ;
  static String time = "Time" ;
  static String add = "Add" ;
  static String done = "Done" ;
  static String dONETASKS = "DONE TASKS" ;
}