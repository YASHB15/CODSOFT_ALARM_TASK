import 'package:equatable/equatable.dart';

abstract class Failur extends Equatable {
  @override
  List<Object?> get props => [];
}

class EmpityFailur extends Failur {
  @override
  List<Object?> get props => [];
}

class SqlFailur extends Failur {
  @override
  List<Object?> get props => [];
}

