class EmpityException implements Exception {}
class SqlException implements Exception {}